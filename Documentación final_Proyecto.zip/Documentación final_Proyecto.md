﻿


**ESCUELA SUPERIOR POLITÉCNICA DEL LITORAL**

**FACULTAD DE INGENIERÍA EN ELECTRICIDAD Y COMPUTACIÓN**

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.001.png)



**SISTEMAS EMBEBIDOS**

***Documento de diseño***

Proyecto “Battleship” 

**Estudiante**

STEVEN AARÓN REYES YAGUAL


**Paralelo**

3

**Docente**

ING. MARÍA ISABEL MERA COLLANTES 


**I PAO 2025**


1. **Introducción**

El objetivo del proyecto es realizar un sistema de juego dinámico y entretenido para el público en general, contando con un ranking de puntos para mayor competitividad. Además de contar con un pequeño programa que guarda información y envía los datos a la nube.  Además, con el objetivo de ofrecer una experiencia más completa y organizada, el sistema almacena la información básica de cada jugador en una base de datos remota utilizando, en este caso, Supabase. Esto permite que, una vez iniciada la sesión desde el celular, se registren automáticamente datos como el nombre del jugador, su progreso en la partida y el historial de rendimiento. Esta integración facilita el seguimiento de los usuarios entre sesiones, y sienta las bases para futuras funciones como rankings, análisis de juego o desafíos personalizados.

1. **Alcance y Limitaciones**

**Alcance:** En base a la creación de un juego interactivo, se busca solventar la necesidad de tener divertidos contra aquellos momentos de aburrimiento o simplicidad en reunión de amigos o familiares, con una idea creativa que engloba conocimientos de sistemas digitales y computacionales.** Comprende el uso de un microcontrolador ESP32, 2 matrices LED 8x8 agrupadas en cuadros de 2x2, además de hacer uso de 2 teclados matriciales 4x4 para cada jugador.

**Limitaciones:** Un limitante es el hecho de que, en el modo de multijugador, solo se pueden conectar 2 jugadores a la vez para un enfrentamiento 1 vs 1, pero no más de eso, esto debido a que el juego no está configurado para más jugadores por tema de dispositivos microcontroladores ESP32 que se necesitarían. Otra limitante es la visibilidad de los estados durante el proceso de carga y juego, debido a que para el producto final, se decidió retirar la pantalla LCD por un buzzer para indicar un cambio de estado. 

1. ![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.002.png)**Diagrama de contexto**
1. ![Diagrama

El contenido generado por IA puede ser incorrecto.](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.003.png)**Diagrama de bloques del Diseño**

***True***

***True***
1. ![ref1]![ref1]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.005.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.006.png)**Diagrama de software o Máquina de Estados**

***True***

Selección de modo

Acceso a la IP de juego

**Pantalla principal**

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.007.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.008.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.009.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.010.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.011.png)

**ENCENDIDO**

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.012.png)

***False***

***False***

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.013.png)![ref2]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.015.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.016.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.017.png)

***False***

***False***

***False***

***True***

![ref2]![ref2]![ref2]![ref1]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.018.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.019.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.020.png)

***False***

![ref2]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.021.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.022.png)

**Fin de juego**

Lanzamiento Jugador 2

Selección de posiciones

Nombre de jugadore(es)

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.023.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.024.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.025.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.026.png)

***True***

***False***

![ref1]![ref2]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.027.png)

***True***

¿3 posiciones acertadas?


![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.028.png)![ref1]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.029.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.030.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.031.png)

***False***

***True***

***True***

Lanzamiento Jugador 1

![ref2]![ref1]![ref1]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.032.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.033.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.034.png)

***False***

***True***
![ref2]![ref1]![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.035.png)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.036.png)

1. **Diagrama/Diseño de Interfaces**

Se ha logrado una interfaz de usuario capaz amigable y sencilla capaz de receptar las ubicaciones de 3 “barcos” del tablero digital 4x4 desde el móvil impulsado por la dirección IP del microcontrolador. Esta interfaz logrará dar inicio al juego una vez que las ubicaciones sean seleccionadas en dicho tablero. El juego está diseñado para un máximo de 2 personas, pero considerando que cada jugador tendrá su propio “comando”, entonces es necesario la sincronización de 2 microcontroladores y por ende la necesidad de tener una interfaz de usuario global para el juego general.

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.037.png)![Interfaz de usuario gráfica, Aplicación

El contenido generado por IA puede ser incorrecto.](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.038.jpeg)![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.039.png)








1. **Alternativas de Diseño**
1. ![Calendario

El contenido generado por IA puede ser incorrecto.](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.040.jpeg)**Battleship Computer with ESP32 / WS2812 LED Stripe**

Este proyecto detalla la construcción de una computadora para el juego de Batalla Naval, centrada en el uso de un ESP32 y una tira de LEDs WS2812 para crear un tablero de juego físico. El objetivo principal es que las tiras de LED representen visualmente los impactos en el campo de batalla.

[**https://www.instructables.com/Battleship-Computer-With-ESP32-WS2812-LED-Stripe/**](https://www.instructables.com/Battleship-Computer-With-ESP32-WS2812-LED-Stripe/)

1. **Battleship con Pantalla LCD de estados** 

![](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.041.png)Otra alternativa que se había considerado como diseño principal y original es que el producto este acompañado de una pantalla LCD pequeña que muestre mensajes en cada etapa del juego dirigidas al jugador, así como también muestre el estado del proceso de juego mientras inicia la ronda o la conectividad a alguna red local para enlazar el juego al móvil. Esto eliminaría la posibilidad de acudir a Telegram para poder mostrar la dirección IP del juego que depende de la red Wifi en la que se conectó el microcontrolador.

1. ![Imagen que contiene circuito, computadora

El contenido generado por IA puede ser incorrecto.](Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.042.jpeg)**Plan de Test y Validación**
- Verificar la respuesta de las 2 matrices Led 8x8 junto con ambos keypad 4x4 en base al estado actual del juego (Así se comprueba tanto conexiones como correcta lectura de código en la ESP32, todo esto en Protoboard).
- Poner a prueba la conexión a la página del juego con el encendido y apagado del mismo, así con este test de estrés, verificamos que esté trabajando en condiciones 
- Monitorear la durabilidad de las baterías AAA en el juego.
- Realizar unas pruebas de satisfacción en base al uso de proyecto con compañeros de clase y jóvenes universitarios para reconocer sugerencias y recomendaciones estéticas.
1. **Consideraciones Éticas**

En muchos productos digitales o tecnológicos diseñados, existen cuestionamientos por parte del público en general o de los mismos diseñadores del rumbo que puede tomar el nuevo producto lanzado al mercado, pero, aunque el proyecto del juego dinámico de “battleship” no se considera que tenga tiene nociones éticas importantes o directamente relacionados con problemáticas de índole mundial, se puede dar el caso de que emociones como, el resentimientos o confrontación se den paso en lugar de la competitividad y rivalidad, pero el juego se hizo para entretenimiento y diversión entre amigos, donde queda abierta la posibilidad de realizar torneos con premios para todos los jugadores y así mitigar ciertos pensamientos negativos. 

Ahora si el punto de vista es más detallista con cuestionamientos éticos, puede ser que el producto tenga cierta tendencia a un comportamiento de adicción por parte de los jugadores y puede estar afectando su desempeño ordinario, por ende, es necesario recapitular para donde se quiere llegar con el producto y como el usuario debería usarlo normalmente. 

[ref1]: Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.004.png
[ref2]: Aspose.Words.b7ea425c-263f-44a4-a6de-dd06286ef9d9.014.png
